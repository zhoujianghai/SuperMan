#include "GameOverScene.h"
#include "TitleScene.h"
#include "global.h"
#include "tools.h"

using namespace cocos2d;


bool GameOverScene::init()
{
	bool bRet = false;
	do 
	{
		CCSize size = CCDirector::sharedDirector()->getWinSize();

		std::string titleStr = "��Ϸ����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(titleStr,"gb2312","utf-8");
#endif
		CCLabelTTF* pLabel = CCLabelTTF::labelWithString(titleStr.c_str(), "Thonburi", 30);
		CC_BREAK_IF(! pLabel);
		pLabel->setColor(ccRED);
		// Get window size and place the label upper. 		
		pLabel->setPosition(ccp(size.width / 2, size.height*0.9f));
		// Add the label to TitleScene layer as a child layer.
		this->addChild(pLabel, 1);

		std::string keepTime="������";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(keepTime,"gb2312","utf-8");
#endif
		std::string second="��";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(second,"gb2312","utf-8");
#endif
		char szBuf[128];
		memset(szBuf,0,sizeof(szBuf));
		sprintf(szBuf,"%d",(int)g_gameTime);
		std::string titleStr3=keepTime+szBuf+second;
		CCLabelTTF *pLabel3=CCLabelTTF::labelWithString(titleStr3.c_str(),"Thonburi",30);
		CC_BREAK_IF(! pLabel3);
		pLabel3->setColor(ccRED);
		// Get window size and place the label upper. 		
		pLabel3->setPosition(ccp(size.width / 2, size.height*0.7f));
		// Add the label to TitleScene layer as a child layer.
		this->addChild(pLabel3, 1);

		std::string yourAppraise="���õ������ǣ�";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(yourAppraise,"gb2312","utf-8");
#endif
		CCLabelTTF* pLabel4 = CCLabelTTF::labelWithString(yourAppraise.c_str(), "Thonburi", 30);
		CC_BREAK_IF(! pLabel4);
		pLabel4->setColor(ccWHITE);
		// Get window size and place the label upper. 		
		pLabel4->setPosition(ccp(size.width / 2, size.height*0.5f));
		// Add the label to TitleScene layer as a child layer.
		this->addChild(pLabel4, 1);

		std::string appraise=convertAppraise();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(appraise,"gb2312","utf-8");
#endif
		CCLabelTTF* pLabel5 = CCLabelTTF::labelWithString(appraise.c_str(), "Thonburi", 30);
		CC_BREAK_IF(! pLabel5);
		pLabel5->setColor(ccWHITE);
		// Get window size and place the label upper. 		
		pLabel5->setPosition(ccp(size.width / 2, size.height*0.3f));
		// Add the label to TitleScene layer as a child layer.
		this->addChild(pLabel5, 1);

		std::string titleStr2 = "�����Ļ����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(titleStr2,"gb2312","utf-8");
#endif
		CCLabelTTF* pLabel2 = CCLabelTTF::labelWithString(titleStr2.c_str(), "Thonburi", 30);
		CC_BREAK_IF(! pLabel2);
		pLabel2->setColor(ccRED);
		// Get window size and place the label upper. 		
		pLabel2->setPosition(ccp(size.width / 2, size.height*0.1f));
		// Add the label to TitleScene layer as a child layer.
		this->addChild(pLabel2, 1);

		this->setIsTouchEnabled(true);

		bRet = true;
	}while (0);

	return bRet;
}

cocos2d::CCScene* GameOverScene::scene()
{
	CCScene * scene = NULL;
	do 
	{
		// 'scene' is an autorelease object
		scene = CCScene::node();
		CC_BREAK_IF(! scene);

		// 'layer' is an autorelease object
		GameOverScene *layer = GameOverScene::node();
		CC_BREAK_IF(! layer);

		// add layer as a child to scene
		scene->addChild(layer);
	} while (0);

	// return the scene
	return scene;
}

void GameOverScene::ccTouchesBegan( cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent )
{
	CCScene *scene=TitleScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionFade::transitionWithDuration(1.2f,scene));
}

std::string GameOverScene::convertAppraise()
{
	std::string appraise;

	switch((int)g_gameTime)
	{
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
		appraise="��������";
		break;
	case 7:
		appraise="�����";
		break;
	case 8:
		appraise="��Ӱ����֮��������";
		break;
	case 9:
		appraise="ʥ������";
		break;
	case 10:
		appraise="С���Ÿ�";
		break;
	case 11:
		appraise="˹�ʹ�������ʿ֮������һ";
		break;
	case 12:
		appraise="����A�εĿ㶵";
		break;
	case 13:
		appraise="����µĺ���";
		break;
	case 14:
		appraise="�������ص��۾�";
		break;
	case 15:
		appraise="����������������";
		break;
	case 16:
		appraise="���˵Ŀ���";
		break;
	case 17:
		appraise="����յ�β��";
		break;
	case 18:
		appraise="����ģ����ھ�";
		break;
	case 19:
		appraise="����ģ���㰲ο��";
		break;
	case 20:
	default:
		appraise="���������һ������";
	}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
	GBKToUTF8(appraise,"gb2312","utf-8");
#endif

	return appraise;
}

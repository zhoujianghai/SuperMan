#include "TitleScene.h"
#include "FlyScene.h"
#include "SettingScene.h"
#include "tools.h"

using namespace cocos2d;

CCScene* TitleScene::scene()
{
    CCScene * scene = NULL;
    do 
    {
        // 'scene' is an autorelease object
        scene = CCScene::node();
        CC_BREAK_IF(! scene);

        // 'layer' is an autorelease object
        TitleScene *layer = TitleScene::node();
        CC_BREAK_IF(! layer);

        // add layer as a child to scene
        scene->addChild(layer);
    } while (0);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool TitleScene::init()
{
    bool bRet = false;
    do 
    {
        //////////////////////////////////////////////////////////////////////////
        // super init first
        //////////////////////////////////////////////////////////////////////////

        CC_BREAK_IF(! CCLayer::init());

        //////////////////////////////////////////////////////////////////////////
        // add your codes below...
        //////////////////////////////////////////////////////////////////////////
        //���ӱ���
		std::string titleStr = "�����˾ͼ��20��";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(titleStr,"gb2312","utf-8");
#endif
        CCLabelTTF* pLabel = CCLabelTTF::labelWithString(titleStr.c_str(), "Thonburi", 30);
		CC_BREAK_IF(! pLabel);
		pLabel->setColor(ccRED);

        // Get window size and place the label upper. 
        CCSize size = CCDirector::sharedDirector()->getWinSize();
        pLabel->setPosition(ccp(size.width / 2, size.height*0.8f));

        // Add the label to TitleScene layer as a child layer.
        this->addChild(pLabel, 1);

        //���ӱ���
        CCSprite* pSprite = CCSprite::spriteWithFile("background.png");
        CC_BREAK_IF(! pSprite);

        // Place the sprite on the center of the screen
        pSprite->setPosition(ccp(size.width/2, size.height/2));

        // Add the sprite to TitleScene layer as a child layer.
        this->addChild(pSprite, 0);

		//����Ŀ¼
		CCMenuItemFont::setFontName("Thonburi");
		CCMenuItemFont::setFontSize(25);

		std::string menuItemStr = "����Ϸ";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(menuItemStr,"gb2312","utf-8");
#endif
		CCMenuItem *newGame = CCMenuItemFont::itemFromString(menuItemStr.c_str(),this,menu_selector(TitleScene::menuNewCallback));

		menuItemStr = "����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(menuItemStr,"gb2312","utf-8");
#endif
		CCMenuItem *optionGame=CCMenuItemFont::itemFromString(menuItemStr.c_str(),this,menu_selector(TitleScene::menuOptionCallback));

		menuItemStr = "�˳�";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(menuItemStr,"gb2312","utf-8");
#endif
		CCMenuItem *quitGame=CCMenuItemFont::itemFromString(menuItemStr.c_str(),this,menu_selector(TitleScene::menuQuitCallback));

		CCMenu *menu=CCMenu::menuWithItems(newGame,optionGame,quitGame,NULL);
		menu->alignItemsVertically();//��ֱ����

		addChild(menu,1);

        bRet = true;
    } while (0);

    return bRet;
}

void TitleScene::menuQuitCallback(CCObject* pSender)
{
    // "close" menu item clicked
    CCDirector::sharedDirector()->end();
}

void TitleScene::menuNewCallback( CCObject* pSender )
{
	CCScene *scene=FlyScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionCrossFade::transitionWithDuration(1.2f,scene));
}

void TitleScene::menuOptionCallback( CCObject* pSender )
{
	CCScene *scene=SettingScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionFlipX::transitionWithDuration(1.2f,scene));
}


#ifndef __FLYSCENE_SCENE_H__
#define __FLYSCENE_SCENE_H__

#include <vector>
#include "cocos2d.h"
#include "SimpleAudioEngine.h"

class FlyScene: public cocos2d::CCLayer
{
public:
	// Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
	virtual bool init();  

	// there's no 'id' in cpp, so we recommand to return the exactly class pointer
	static cocos2d::CCScene* scene();

	virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
	virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
	virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);

	// implement the "static node()" method manually
	LAYER_NODE_FUNC(FlyScene);
private:
	void menuReturnCallback(cocos2d::CCObject *pSender);

	void createBullet(cocos2d::ccTime dt);
	void flying(cocos2d::ccTime dt);
	void checkBullet(cocos2d::ccTime dt);
	void saveTime(cocos2d::ccTime dt);
	void explosionEndDid();

	//ҡ�����
	cocos2d::CCSprite *joystick;
	cocos2d::CCPoint centre;
	float radius;

	//�ɻ����
	cocos2d::CCSprite *plane;
	float speedX;
	float speedY;
	bool isFlying;	

	//�ӵ����
	std::vector<cocos2d::CCSprite*> bullets;

	//��ը���
	cocos2d::CCSprite *explosion;
};
#endif  // __FLYSCENE_SCENE_H__
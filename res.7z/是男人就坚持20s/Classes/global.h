#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include "cocos2d.h"

extern cocos2d::ccTime g_gameTime;

extern int g_bulletNum;

extern bool g_isPlaySoundEffect;

#endif //_GLOBAL_H_
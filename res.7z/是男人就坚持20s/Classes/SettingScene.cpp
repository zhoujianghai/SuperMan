#include "SettingScene.h"
#include "TitleScene.h"
#include "tools.h"
#include "global.h"

using namespace cocos2d;

bool SettingScene::init()
{
	bool bRet = false;
	do 
	{
		CCMenuItemFont::setFontName("American Typewriter");
		CCMenuItemFont::setFontSize(18);

		//��������
		std::string str = "����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItemFont *title1 = CCMenuItemFont::itemFromString(str.c_str(),NULL,NULL);
		title1->setIsEnabled(false);

		str = "��";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItemFont *openItem = CCMenuItemFont::itemFromString(str.c_str());

		str = "��";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItemFont *closeItem = CCMenuItemFont::itemFromString(str.c_str());

		CCMenuItemToggle *soundItem = CCMenuItemToggle::itemWithTarget(this,menu_selector(SettingScene::soundCallback),openItem,closeItem,NULL);

		soundItem->setSelectedIndex(g_isPlaySoundEffect?0:1);

		//��������
		str = "����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItemFont *title2 = CCMenuItemFont::itemFromString(str.c_str(),NULL,NULL);
		title2->setIsEnabled(false);

		str = "50";
		CCMenuItemFont *bulletNum50Item = CCMenuItemFont::itemFromString(str.c_str());

		str = "100";
		CCMenuItemFont *bulletNum100Item = CCMenuItemFont::itemFromString(str.c_str());

		str = "150";
		CCMenuItemFont *bulletNum150Item = CCMenuItemFont::itemFromString(str.c_str());

		CCMenuItemToggle *bulletNumItem = CCMenuItemToggle::itemWithTarget(this,menu_selector(SettingScene::bulletNumCallback),bulletNum50Item,bulletNum100Item,bulletNum150Item,NULL);

		bulletNumItem->setSelectedIndex(g_bulletNum/50-1);

		CCMenuItemFont::setFontName("Marker Felt");
		CCMenuItemFont::setFontSize(26);

		//����
		str = "����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItem *back =CCMenuItemFont::itemFromString(str.c_str(),this,menu_selector(SettingScene::backCallback));

		//���ڲ���
		CCMenu *menu = CCMenu::menuWithItems(title1,soundItem,title2,bulletNumItem,back,NULL);
		menu->alignItemsInColumns(2,2,1);
		this->addChild(menu);

		back->setScale(0.8f);
		back->setPosition(ccp(back->getPosition().x,back->getPosition().y - 20));

		bRet = true;
	} while (0);

	return bRet;
}

cocos2d::CCScene* SettingScene::scene()
{
	CCScene * scene = NULL;
	do 
	{
		// 'scene' is an autorelease object
		scene = CCScene::node();
		CC_BREAK_IF(! scene);

		// 'layer' is an autorelease object
		SettingScene *layer = SettingScene::node();
		CC_BREAK_IF(! layer);

		// add layer as a child to scene
		scene->addChild(layer);
	} while (0);

	// return the scene
	return scene;
}

void SettingScene::backCallback( cocos2d::CCObject *pSender )
{
	CCScene *scene=TitleScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionFlipX::transitionWithDuration(1.2f,scene));
}

void SettingScene::soundCallback( cocos2d::CCObject *pSender )
{
	g_isPlaySoundEffect=!g_isPlaySoundEffect;
}

void SettingScene::bulletNumCallback( cocos2d::CCObject *pSender )
{
	g_bulletNum+=50;

	if(g_bulletNum>150)
	{
		g_bulletNum=50;
	}
}

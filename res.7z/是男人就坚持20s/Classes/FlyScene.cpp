#include "FlyScene.h"
#include "TitleScene.h"
#include "GameOverScene.h"
#include "global.h"
#include "tools.h"

using namespace cocos2d;

bool FlyScene::init()
{
	bool bRet = false;
	do 
	{
		CC_BREAK_IF(! CCLayer::init());

		CCSize s = CCDirector::sharedDirector()->getWinSize();	

		CCSprite *joystick1=CCSprite::spriteWithFile("joystick1.png");
		joystick1->setOpacity(191);
		joystick1->setAnchorPoint(ccp(0,0));
		joystick1->setPosition(ccp(0,0));
		radius=joystick1->getContentSize().width/2;
		centre=ccp(radius,radius);
		this->addChild(joystick1,1);

		joystick=CCSprite::spriteWithFile("joystick2.png");
		joystick->setPosition(ccp(centre.x,centre.y));
		this->addChild(joystick,2);

		//����
		CCMenuItemFont::setFontSize(22);
		CCMenuItemFont::setFontName("American Typewriter");
		std::string str = "";

		str="����";
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		GBKToUTF8(str,"gb2312","utf-8");
#endif
		CCMenuItemFont* systemMenu = CCMenuItemFont::itemFromString(str.c_str(),this,menu_selector(FlyScene::menuReturnCallback));

		CCMenu* mn = CCMenu::menuWithItems(systemMenu,NULL);
		mn->setPosition(ccp(0,0));

		systemMenu->setAnchorPoint(ccp(1,0));
		systemMenu->setPosition(ccp(s.width,0));

		this->addChild(mn,1);

		//�ɻ�
		CCTexture2D *texture=CCTextureCache::sharedTextureCache()->addImage("plane.png");
		plane = CCSprite::spriteWithTexture(texture);
		plane->setPosition(ccp(s.width/2,s.height/2));
		this->addChild(plane,0);

		//��������
		this->setIsTouchEnabled(true);
		//�����߼�
		this->schedule(schedule_selector(FlyScene::flying));
		this->schedule(schedule_selector(FlyScene::createBullet));
		this->schedule(schedule_selector(FlyScene::checkBullet));
		this->schedule(SEL_SCHEDULE(&FlyScene::saveTime),1);
		//��������
		isFlying=false;
		speedX=speedY=0;
		g_gameTime=0;

		bRet = true;
	}while(0);
	return bRet;
}

cocos2d::CCScene* FlyScene::scene()
{
	CCScene * scene = NULL;
	do 
	{
		// 'scene' is an autorelease object
		scene = CCScene::node();
		CC_BREAK_IF(! scene);

		// 'layer' is an autorelease object
		FlyScene *layer = FlyScene::node();
		CC_BREAK_IF(! layer);

		// add layer as a child to scene
		scene->addChild(layer);
	} while (0);

	// return the scene
	return scene;
}

void FlyScene::menuReturnCallback( CCObject *pSender )
{
	CCScene * scene=TitleScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionFlipX::transitionWithDuration(1.2f,scene));
}

void FlyScene::ccTouchesBegan( CCSet *pTouches, CCEvent *pEvent )
{
	CCTouch *touch = (CCTouch*)pTouches->anyObject();
	CCPoint location = touch->locationInView(touch->view());
	CCPoint convertedLocation = CCDirector::sharedDirector()->convertToGL(location);

	CCRect rect=joystick->boundingBox();
	if (CCRect::CCRectContainsPoint(rect,convertedLocation))
	{
		isFlying=true;
	}
}

void FlyScene::ccTouchesMoved( CCSet *pTouches, CCEvent *pEvent )
{
	CCTouch *touch = (CCTouch*)pTouches->anyObject();
	CCPoint location = touch->locationInView(touch->view());
	CCPoint convertedLocation = CCDirector::sharedDirector()->convertToGL(location);

	bool inRange=pow(centre.x-convertedLocation.x,2)+pow(centre.y-convertedLocation.y,2)<pow(radius,2);

	if(isFlying&&inRange)
	{
		CCPoint position=plane->getPosition();
		joystick->setPosition(convertedLocation);

		float radius1=radius*2/6;//ʮ�ּ�������������Բ�뾶
		float side=radius*2/3;//�Ź�����һ�����ӵı߳�

		//����ʹ�ú��׹�ʽ����������������ж�ʮ�ּ��������ľ�ȷ����
		//����
		if(triangleContainPoint(centre.x,centre.y,centre.x-radius1,centre.y+radius1,centre.x+radius1,centre.y+radius1,convertedLocation.x,convertedLocation.y)
			||CCRect::CCRectContainsPoint(CCRectMake(centre.x-radius1,centre.y+radius1,side,side),convertedLocation))
		{
			speedX=0;
			speedY=1;
		}
		//����
		else if(triangleContainPoint(centre.x,centre.y,centre.x-radius1,centre.y-radius1,centre.x+radius1,centre.y-radius1,convertedLocation.x,convertedLocation.y)
			||CCRect::CCRectContainsPoint(CCRectMake(centre.x-radius1,centre.y-radius1-side,side,side),convertedLocation))
		{
			speedX=0;
			speedY=-1;
		}
		//����
		else if(triangleContainPoint(centre.x,centre.y,centre.x-radius1,centre.y+radius1,centre.x-radius1,centre.y-radius1,convertedLocation.x,convertedLocation.y)
			||CCRect::CCRectContainsPoint(CCRectMake(centre.x-radius1-side,centre.y-radius1,side,side),convertedLocation))
		{
			speedX=-1;
			speedY=0;
		}
		//����
		else if (triangleContainPoint(centre.x,centre.y,centre.x+radius1,centre.y+radius1,centre.x+radius1,centre.y-radius1,convertedLocation.x,convertedLocation.y)
			||CCRect::CCRectContainsPoint(CCRectMake(centre.x+radius1+side,centre.y-radius1,side,side),convertedLocation))
		{
			speedX=1;
			speedY=0;
		}
		//����
		else if(convertedLocation.x-centre.x>0&&convertedLocation.y-centre.y>0)
		{
			speedX=0.7f;
			speedY=0.7f;
		}
		//����
		else if (convertedLocation.x-centre.x<0&&convertedLocation.y-centre.y>0)
		{
			speedX=-0.7f;
			speedY=0.7f;
		}
		//����
		else if (convertedLocation.x-centre.x<0&&convertedLocation.y-centre.y<0)
		{
			speedX=-0.7f;
			speedY=-0.7f;
		}
		//����
		else if (convertedLocation.x-centre.x>0&&convertedLocation.y-centre.y<0)
		{
			speedX=0.7f;
			speedY=-0.7f;
		}
	}
}

void FlyScene::ccTouchesEnded( CCSet *pTouches, CCEvent *pEvent )
{
	isFlying=false;
	joystick->setPosition(centre);
	speedX=speedY=0;
}

void FlyScene::flying( cocos2d::ccTime dt )
{
	if (isFlying&&(speedX!=0||speedY!=0))
	{
		CCPoint position=ccp(plane->getPosition().x+speedX,plane->getPosition().y+speedY);

		CCSize size=CCDirector::sharedDirector()->getWinSize();
		CCRect rect=CCRectMake(0,0,size.width,size.height);

		if(CCRect::CCRectContainsPoint(rect,position))
		{
			plane->setPosition(position);
		}
	}

}

void FlyScene::createBullet( cocos2d::ccTime dt )
{
	if (bullets.size()>g_bulletNum)
	{
		return;
	}

	CCTexture2D *texture=CCTextureCache::sharedTextureCache()->addImage("bullet.png");
	CCSprite *bullet=CCSprite::spriteWithTexture(texture);
	this->addChild(bullet,0);
	bullets.push_back(bullet);

	float x,y;
	int speedX,speedY;
	CCSize size=CCDirector::sharedDirector()->getWinSize();

	int entrance=abs(rand()%4);
	switch(entrance)
	{
	case 0://�ϲ����
		x=abs(rand()%(int)size.width);
		y=size.height-bullet->boundingBox().size.height;
		speedX=rand()%3;
		speedY=(abs(rand()%3+1))*-1;
		break;
	case 1://�²����
		x=abs(rand()%(int)size.width);
		y=bullet->boundingBox().size.height;
		speedX=rand()%3;
		speedY=abs(rand()%3+1);
		break;
	case 2://������
		x=bullet->boundingBox().size.width;
		y=abs(rand()%(int)size.height);
		speedX=abs(rand()%3+1);
		speedY=rand()%3;
		break;
	case 3://�Ҳ����
		x=size.width-bullet->boundingBox().size.width;
		y=abs(rand()%(int)size.height);
		speedX=abs(rand()%3+1)*-1;
		speedY=rand()%3;
		break;
	}

	CCActionInterval *action=CCMoveBy::actionWithDuration(0.1f,ccp(speedX,speedY));

	bullet->setPosition(ccp(x,y));
	bullet->runAction(CCRepeatForever::actionWithAction(action));
}

void FlyScene::checkBullet(cocos2d::ccTime dt)
{
	if (!plane->getIsVisible())
	{
		return;
	}

	CCSize size=CCDirector::sharedDirector()->getWinSize();
	CCRect screen=CCRectMake(0,0,size.width,size.height);
	CCRect planeBox=plane->boundingBox();

	for (std::vector<cocos2d::CCSprite*>::iterator bitr=bullets.begin(); bitr != bullets.end();)
	{
		CCSprite *bullet =*bitr;
		CCPoint position=bullet->getPosition();
		CCRect bulletBox=bullet->boundingBox();

		if (CCRect::CCRectIntersectsRect(planeBox,bulletBox))
		{
			this->removeChild(bullet, true);
			bitr=bullets.erase(bitr);

			plane->setIsVisible(false);

			CCTexture2D *texture=CCTextureCache::sharedTextureCache()->addImage("explosion.png");
			CCAnimation *animation = CCAnimation::animation();
			animation->setDelay(0.2f);
			for(int i=0;i<4;i++)
				animation->addFrameWithTexture(texture,CCRectMake(i*32,0,32,32));
			CCAnimate *animate=CCAnimate::actionWithAnimation(animation);
			CCFiniteTimeAction *animateOver=CCCallFunc::actionWithTarget(this,callfunc_selector(FlyScene::explosionEndDid));
			CCFiniteTimeAction *seq=CCSequence::actions(animate,animateOver,NULL);

			explosion=CCSprite::spriteWithTexture(texture,CCRectMake(0,0,32,32));
			this->addChild(explosion);
			explosion->setPosition(plane->getPosition());
			explosion->runAction(seq);			

			if(g_isPlaySoundEffect)
			CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("explosion.wav");

			break;
		}
		else if (!CCRect::CCRectContainsPoint(screen,position))
		{//�뿪��Ļ��ɾ��
			this->removeChild(bullet, true);
			bitr=bullets.erase(bitr);
		}
		else
		{
			bitr++;
		}
	}
}

void FlyScene::saveTime( cocos2d::ccTime dt )
{
	g_gameTime+=dt;
}

void FlyScene::explosionEndDid()
{
	explosion->setIsVisible(false);
	CCScene *scene=GameOverScene::scene();
	CCDirector::sharedDirector()->replaceScene(CCTransitionFade::transitionWithDuration(1.2f,scene));
}

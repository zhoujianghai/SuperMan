#include "global.h"

cocos2d::ccTime g_gameTime;

 int g_bulletNum;

 bool g_isPlaySoundEffect;